package com.cg.pos.dao;

import com.cg.pos.bean.CardDataUpload;

public interface CardDataUploadDao {

	public String saveCard(CardDataUpload card);

}
