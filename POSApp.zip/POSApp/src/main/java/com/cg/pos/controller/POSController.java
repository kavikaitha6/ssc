package com.cg.pos.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.pos.bean.CardDataUpload;
import com.cg.pos.repository.CardRepository;
import com.cg.pos.service.CardDataUploadService;


@Controller
public class POSController {

	@Autowired
	CardDataUploadService cardService;


	
/*	private String message = "Hello World";

	@RequestMapping("/")
	public ModelAndView welcome(Map<String, Object> model) {
		//model.put("message", this.message);
		return new ModelAndView("index","message",message);
	}*/

	@RequestMapping(path ="/save")
	public String redirect()
	{
		return "CardDataUpload";
	}
	
	@RequestMapping(path = "/save/CardDataUpload", method = RequestMethod.POST)
	public String addCardData(@ModelAttribute("cardFormData") CardDataUpload cardRead)
	{
		String status = cardService.saveCard(cardRead);		
		return status;
	}

}
