package com.cg.pos.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.pos.bean.CardDataUpload;
import com.cg.pos.dao.CardDataUploadDao;

@Repository
@Transactional
public class CardDataUploadServiceImpl implements CardDataUploadService {

@Autowired
CardDataUploadDao carddao;
	 
	@Override
	public String saveCard(CardDataUpload card) {
		
		 return carddao.saveCard(card);
	}

}
