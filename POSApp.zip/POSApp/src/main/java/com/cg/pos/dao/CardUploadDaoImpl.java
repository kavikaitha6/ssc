package com.cg.pos.dao;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.pos.bean.CardDataUpload;
import com.cg.pos.repository.CardRepository;

@Repository
@Transactional
public class CardUploadDaoImpl implements CardDataUploadDao{

/*	 @PersistenceContext
	 private EntityManager entityManager;*/
	 
		@Autowired
		CardRepository cardRepo;
	 
	@Override
	public @ResponseBody String saveCard(CardDataUpload card) {
		 cardRepo.save(card);
		 return "Saved"; // "Saved" is not a view
	}		
	
	}

	