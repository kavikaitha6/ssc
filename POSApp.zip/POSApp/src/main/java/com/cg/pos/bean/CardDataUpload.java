package com.cg.pos.bean;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
@Entity
@Table(name = "carddata")

public class CardDataUpload {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private String primaryAccountNumber;
    @DateTimeFormat
	private String dateExpiration;
	@NotNull
    private String serviceRestrictionCode;
	@NotNull
	private String cvvNumber;
	@NotNull
	private String pinData;
	@NotNull
	private String amount;

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getPrimaryAccountNumber() {
		return primaryAccountNumber;
	}

	public void setPrimaryAccountNumber(String primaryAccountNumber) {
		this.primaryAccountNumber = primaryAccountNumber;
	}

	public String getDateExpiration() {
		return dateExpiration;
	}

	public void setDateExpiration(String dateExpiration) {
		this.dateExpiration = dateExpiration;
	}

	public String getServiceRestrictionCode() {
		return serviceRestrictionCode;
	}

	public void setServiceRestrictionCode(String serviceRestrictionCode) {
		this.serviceRestrictionCode = serviceRestrictionCode;
	}

	public String getCvvNumber() {
		return cvvNumber;
	}

	public void setCvvNumber(String cvvNumber) {
		this.cvvNumber = cvvNumber;
	}

	public String getPinData() {
		return pinData;
	}

	public void setPinData(String pinData) {
		this.pinData = pinData;
	}

	@Override
	public String toString() {
		return "CardDataUpload [primaryAccountNumber=" + primaryAccountNumber + ", dateExpiration=" + dateExpiration
				+ ", serviceRestrictionCode=" + serviceRestrictionCode + ", cvvNumber=" + cvvNumber + ", pinData="
				+ pinData + ", amount=" + amount + "]";
	}

}

