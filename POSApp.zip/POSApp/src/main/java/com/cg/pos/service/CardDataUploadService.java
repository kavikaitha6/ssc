package com.cg.pos.service;

import com.cg.pos.bean.CardDataUpload;

public interface CardDataUploadService {

	public String saveCard(CardDataUpload card);
}
