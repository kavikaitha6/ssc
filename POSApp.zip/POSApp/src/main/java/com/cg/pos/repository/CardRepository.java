package com.cg.pos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.pos.bean.CardDataUpload;

public interface CardRepository extends JpaRepository < CardDataUpload, Long >  {

}
